    #include "widget.h"
#include "ui_widget.h"

#include <QDateTime>
#include <QDebug>
#include <QMessageBox>
#include <QPainter>
#include <QSerialPortInfo>
#include <iostream>
#include <qfiledialog.h>
#include <qtimer.h>
#include "mycombox.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    //初始化
    QTimer *curr_timer = new QTimer(this);
    SerialPort = new QSerialPort(this);
    timer = new QTimer(this);
    loop_timer = new QTimer(this);
    write_total = 0;
    read_total = 0;
    ButtonIndex=0;
    serial_states=false;


    ui->setupUi(this);
    this->setLayout(ui->gridLayout_total);

    //初始默认
    ui->comboBox_data->setCurrentIndex(3);
    ui->comboBox_baud->setCurrentIndex(6);
    ui->groupBox_4->setEnabled(false);
    ui->groupBoxTexts->setEnabled(false);

    //连接
    //串口连接
    connect(SerialPort,&QSerialPort::readyRead,this,&Widget::on_SerialData_readyToRead);
    //定时发送的定时器连接
    connect(timer,&QTimer::timeout,this,&Widget::on_pushButton_send_clicked);
    //当前时间的定时器
    connect(curr_timer, &QTimer::timeout, this, &Widget::getSysTime);
    curr_timer->start(100);
    getSysTime();
    //串口检测刷新
    connect(ui->comboBox_serialNum,&Mycombox::refresh,this,&Widget::refresh_serialNum);
    //循环发送定时器连接
    connect(loop_timer,&QTimer::timeout,this,&Widget::mult_button_handler);

    //多文本按钮连接
    for (int i = 1; i<=9 ; i++) {
        QString btnName = QString("pushButton_%1").arg(i);
        QPushButton *btn = findChild<QPushButton*>(btnName);
        if(btn){
            btn->setProperty("btnID",i);
            buttons.append(btn);
            connect(btn,SIGNAL(clicked()),this,SLOT(on_mult_btn_clicked()));
        }
        QString lineName = QString("lineEdit_%1").arg(i);
        QLineEdit *line =findChild<QLineEdit*>(lineName);
        if(line)
            lineEdits.append(line);

        QString checkBoxName = QString("checkBox_%1").arg(i);
        QCheckBox *checkBox =findChild<QCheckBox*>(checkBoxName);
        if(checkBox)
            checkBoxs.append(checkBox);
    }

}

Widget::~Widget()
{
    delete ui;
}

//打开串口
void Widget::on_pushButton_closeSerial_clicked()
{
    if(!serial_states){
        //端口号
        SerialPort->setPortName(ui->comboBox_serialNum->currentText());
        //波特率
        SerialPort->setBaudRate(ui->comboBox_baud->currentText().toInt());
        //数据位
        SerialPort->setDataBits(QSerialPort::DataBits(ui->comboBox_data->currentText().toUInt()));
        //停止位
        SerialPort->setStopBits(QSerialPort::StopBits(ui->comboBox_stop->currentText().toUInt()));
        //流控
        if(ui->comboBox_2->currentText()=="None")
            SerialPort->setFlowControl(QSerialPort::NoFlowControl);
        //检验位
        switch(ui->comboBox_check->currentIndex()){
            case 0:
                SerialPort->setParity(QSerialPort::NoParity);
                break;
            case 1:
                SerialPort->setParity(QSerialPort::EvenParity);
                break;
            case 2:
                SerialPort->setParity(QSerialPort::MarkParity);
                break;
            case 3:
                SerialPort->setParity(QSerialPort::OddParity);
                break;
            case 4:
                SerialPort->setParity(QSerialPort::SpaceParity);
                break;
            default:
                SerialPort->setParity(QSerialPort::UnknownParity);
            break;
        }

        //打开
        if(SerialPort->open(QIODevice::ReadWrite)){
            qDebug()<<"success";
            ui->groupBox_2->setEnabled(false);
            ui->pushButton_closeSerial->setText("关闭串口");
            serial_states=true;
        }else{
            QMessageBox megbox;
            megbox.setWindowTitle("错误");
            megbox.setText("串口打开失败");
            megbox.exec();
        }
        ui->groupBox_4->setEnabled(true);
        ui->groupBoxTexts->setEnabled(true);

    }else{
        //左下角组
        SerialPort->close();
        serial_states=false;
        ui->pushButton_closeSerial->setText("打开串口");
        ui->groupBox_2->setEnabled(true);
        //右下角组
        ui->groupBox_4->setEnabled(false);
        ui->checkBox_sendAtTime->setCheckState(Qt::Unchecked);
        timer->stop();
        //右上角组
        ui->groupBoxTexts->setEnabled(false);
    }


}
//发送
void Widget::on_pushButton_send_clicked()
{
    int write_cnt=0;
    const char *sendData = ui->lineEdit_sendFrame->text().toLocal8Bit().constData();

    //判断HEX发送
    if(ui->checkBox_sendHEX->isChecked()){
        QByteArray tmp = ui->lineEdit_sendFrame->text().toLocal8Bit();
        //偶数位判断
        if(tmp.size() %2 != 0){
            ui->label_sendStates->setText("Input ERROR");
            return;
        }
        //符合十六进制格式判断
        for(char c: tmp){
            if(!isxdigit(c)){
                ui->label_sendStates->setText("Input ERROR");
                return;
            }
        }
        QByteArray arrysend=QByteArray::fromHex(tmp);
        write_cnt = SerialPort->write(arrysend);
    }else{
        //发送新行
        if(ui->checkBox_sendFormate->isChecked()){
            QByteArray arraySendData(sendData);
            arraySendData.append("\r\n");
            write_cnt = SerialPort->write(arraySendData);
        }
        write_cnt = SerialPort->write(sendData);
    }

    //发送失败
    if(write_cnt==-1){
        ui->label_sendStates->setText("Send ERROR!");
    }else{
        //发送计数
        write_total+=write_cnt;
        ui->label_Sent->setText("Sent:"+QString::number(write_total));
        //发送状态
        ui->label_sendStates->setText("Send OK!");
        //打印
        if(strcmp(sendData,sendbak.toStdString().c_str())!=0){
            ui->textRecord->append(sendData);
            sendbak=QString::fromUtf8(sendData);
        }
    }
}
//接收
void Widget::on_SerialData_readyToRead()
{
    QString revMessage = SerialPort->readAll();
    if(revMessage != NULL){
        //接收时间
        if(ui->checkBox_RevTime->isChecked())revMessage.append("【"+formattedTime+"】");
        //自动换行
        if(ui->checkBox_autoWrap->isChecked())revMessage.append("\r\n");

        // HEX是否显示
        if(ui->checkBox_HEXdisplay->isChecked()){
            QString tmp_HEX = revMessage.toUtf8().toHex().toUpper(); // 转换为大写
            QString formatted_HEX;

            // 每两个字符后加一个空格
            for(int i = 0; i < tmp_HEX.size(); i += 2){
                formatted_HEX += tmp_HEX.mid(i, 2); // 取两个字符
                formatted_HEX += " ";
            }
            //连接字符发送
            QString tmp_string = ui->textEdit->toPlainText();
            ui->textEdit->setText(tmp_string + formatted_HEX);
        }else{
            // 非HEX
            ui->textEdit->insertPlainText(revMessage);
        }
        read_total += revMessage.size();
        ui->label_Recevied->setText("Received:" + QString::number(read_total));
        //光标
        ui->textEdit->moveCursor(QTextCursor::End);
        ui->textEdit->ensureCursorVisible();
    }
}
//定时发送
void Widget::on_checkBox_sendAtTime_clicked(bool checked)
{
    if(checked){
        timer->start(ui->lineEdit_10->text().toUInt());
        ui->lineEdit_sendFrame->setEnabled(false);
        ui->lineEdit_10->setEnabled(false);
        ui->pushButton_send->setEnabled(false);
    }else{
        timer->stop();
        ui->lineEdit_sendFrame->setEnabled(true);
        ui->lineEdit_10->setEnabled(true);
        ui->pushButton_send->setEnabled(true);
    }
}
//清空接收
void Widget::on_pushButton_clearRev_clicked()
{
    ui->textEdit->clear();
}
//保存接收
void Widget::on_pushButton_saveRev_clicked()
{
    QString filename = QFileDialog::getSaveFileName(this,tr("保存文件"),"E:/qt",tr("Text(*.txt)"));
    if(filename !=NULL){
        QFile file(filename);
        if(!file.open(QIODevice::WriteOnly|QIODevice::Text)){
            qDebug()<<"open error";
            return;
        }
        this->setWindowTitle(filename+"note");
        QTextStream out(&file);
        out.setCodec("UTF-8");
        QString context = ui->textEdit->toPlainText();
        out<<context;
        file.close();
    }
}
//当前时间
void Widget::getSysTime()
{
    QDateTime mytime = QDateTime::currentDateTime();
    QDate date = mytime.date();   // 获取日期部分
    QTime time = mytime.time();   // 获取时间部分

    formattedTime = QString("%1-%2-%3 %4:%5:%6")
                                .arg(date.year())       // 年
                                .arg(date.month(), 2, 10 , QChar('0'))
                                .arg(date.day(), 2, 10,QChar('0'))
                                .arg(time.hour(), 2, 10,QChar('0'))
                                .arg(time.minute(), 2, 10,QChar('0'))
                                .arg(time.second(), 2, 10,QChar('0'));
    ui->label_time->setText(formattedTime);
}
//HEX显示
void Widget::on_checkBox_HEXdisplay_clicked(bool checked)
{
    if(checked){
        QString tmp = ui->textEdit->toPlainText();
        QByteArray b_tmp = tmp.toUtf8().toHex();
        tmp = QString::fromUtf8(b_tmp);
        QString final_show;
        //设置十六进制格式
        for(int i = 0;i<tmp.size();i+=2){
            final_show += tmp.mid(i,2)+" ";
        }

        ui->textEdit->setText(final_show.toUpper());
    }else{
        QString tmp = ui->textEdit->toPlainText();
        QByteArray b_tmp = QByteArray::fromHex(tmp.toUtf8());
        ui->textEdit->setText(QString::fromUtf8(b_tmp));

        //解决setText会使光标回到开头的问题
        QTextDocument *document = ui->textEdit->document();
        // 创建一个光标对象
        QTextCursor cursor(document);
        // 将光标移动到文档末尾
        cursor.movePosition(QTextCursor::End);
        // 将光标设置回 QTextEdit
        ui->textEdit->setTextCursor(cursor);
    }
    ui->textEdit->moveCursor(QTextCursor::End);
    ui->textEdit->ensureCursorVisible();

}
//隐藏面板
void Widget::on_pushButton_hidePanel_clicked(bool checked)
{
    if(checked){
        ui->pushButton_hidePanel->setText("扩展面板");
        ui->groupBoxTexts->hide();
    }else{
        ui->pushButton_hidePanel->setText("隐藏面板");
        ui->groupBoxTexts->show();
    }
}
//隐藏历史
void Widget::on_pushButton_hideHistory_clicked(bool checked)
{
    if(checked){
        ui->pushButton_hideHistory->setText("显示历史");
        ui->groupBoxRecord->hide();
    }else{
        ui->pushButton_hideHistory->setText("隐藏历史");
        ui->groupBoxRecord->show();
    }
}
//串口检测
void Widget::refresh_serialNum()
{
    ui->comboBox_serialNum->clear();
    //串口检测
    QList<QSerialPortInfo> serialList = QSerialPortInfo::availablePorts();
    for(auto SerialPort:serialList)
        ui->comboBox_serialNum->addItem(SerialPort.portName());
}
//多文本发送
void Widget::on_mult_btn_clicked()
{
    QPushButton *btn=qobject_cast<QPushButton*>(sender());
    if(btn){
        //寻找控件索引
        int num = btn->property("btnID").toInt();
        //查询控件名字
        QString lineEditName = QString("lineEdit_%1").arg(num);
        //寻找控件
        QLineEdit *line = findChild<QLineEdit*>(lineEditName);
        if(line)
            if(line->text().size()<=0)
                return;
            ui->lineEdit_sendFrame->setText(line->text());

        //HEX发送
        QString checkbox_name = QString("checkBox_%1").arg(num);
        QCheckBox *check = findChild<QCheckBox*>(checkbox_name);
        if(check)
            ui->checkBox_sendHEX->setChecked(check->isChecked());
        //发送
        on_pushButton_send_clicked();
    }
}
//循环发送执行
void Widget::mult_button_handler()
{
    if(ButtonIndex < buttons.size()){
        QPushButton *btn = buttons[ButtonIndex];
        emit btn->click();
        ButtonIndex++;
    }else {
        ButtonIndex=0;
    }
}
//循环发送
void Widget::on_checkBox_10_clicked(bool checked)
{
    if(checked){
        loop_timer->start(ui->spinBox->text().toUInt());
    }else{
        loop_timer->stop();
    }
}
//重置
void Widget::on_pushButton_12_clicked()
{
    QMessageBox msgbox;
    msgbox.setIcon(QMessageBox::Question);
    msgbox.setWindowTitle("提示");
    msgbox.setText("重置不可逆，是否继续？");
    QPushButton *yesBtn = msgbox.addButton("是",QMessageBox::YesRole);
    QPushButton *noBtn = msgbox.addButton("否",QMessageBox::NoRole);
    msgbox.exec();

    if(msgbox.clickedButton()==yesBtn){
        //清空
        for (int i= 0;i<lineEdits.size();i++) {
            lineEdits[i]->clear();
            checkBoxs[i]->setChecked(false);
        }
    }
    else if(msgbox.clickedButton()==noBtn){
    }
}
//保存
void Widget::on_pushButton_10_clicked()
{
    QString filename = QFileDialog::getSaveFileName(
                this,tr("保存文件"),"E:/qt",tr("Text(*.txt)"));
    if(filename !=NULL){
        QFile file(filename);
        if(!file.open(QIODevice::WriteOnly|QIODevice::Text)){
            qDebug()<<"open error";
            return;
        }
        QTextStream out(&file);
        for (int i = 0;i<lineEdits.size();i++) {
            out<<checkBoxs[i]->isChecked()<<"|"<<lineEdits[i]->text()<<"\n";
        }
        file.close();
    }
}
//载入
void Widget::on_pushButton_11_clicked()
{
    int i=0;
    QString filename = QFileDialog::getOpenFileName(
                this,tr("打开文件"),"E:/qt",tr("Text(*.txt)"));
    if(filename !=NULL){
        QFile file(filename);
        if(!file.open(QIODevice::ReadOnly|QIODevice::Text)){
            qDebug()<<"open error";
            return;
        }
        QTextStream in(&file);

        //读入
        while(!in.atEnd() && i<lineEdits.size()){
            QString line = in.readLine();
            QStringList part = line.split("|");
            checkBoxs[i]->setChecked(part[0].toInt());
            lineEdits[i]->setText(part[1]);
            i++;
        }
    }
}

