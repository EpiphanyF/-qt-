#ifndef MYCOMBOX_H
#define MYCOMBOX_H

#include <QWidget>
#include <qcombobox.h>

class Mycombox : public QComboBox
{
    Q_OBJECT
public:
    Mycombox(QWidget *parent);
protected:
    void mousePressEvent(QMouseEvent *e) override;
signals:
    void refresh();
};

#endif // MYCOMBOX_H
