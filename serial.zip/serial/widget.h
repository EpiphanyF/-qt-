#ifndef WIDGET_H
#define WIDGET_H

#include <QLineEdit>
#include <QPushButton>
#include <QSerialPort>
#include <QTimer>
#include <QWidget>
#include <qcheckbox.h>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();


private slots:
    //打开串口
    void on_pushButton_closeSerial_clicked();
    //发送
    void on_pushButton_send_clicked();
    //接收
    void on_SerialData_readyToRead();
    //定时发送
    void on_checkBox_sendAtTime_clicked(bool checked);
    //清空接收
    void on_pushButton_clearRev_clicked();
    //保存接收
    void on_pushButton_saveRev_clicked();
    //HEX显示
    void on_checkBox_HEXdisplay_clicked(bool checked);
    //隐藏面板
    void on_pushButton_hidePanel_clicked(bool checked);
    //隐藏历史
    void on_pushButton_hideHistory_clicked(bool checked);
    //串口检测
    void refresh_serialNum();
    //多文本发送
    void on_mult_btn_clicked();
    //循环发送
    void on_checkBox_10_clicked(bool checked);
    //当前时间
    void getSysTime();
    //循环发送执行
    void mult_button_handler();
    //重置
    void on_pushButton_12_clicked();
    //保存
    void on_pushButton_10_clicked();
    //载入
    void on_pushButton_11_clicked();


private:
    Ui::Widget *ui;
    //串口
    QSerialPort *SerialPort;
    //发送接收计数
    int write_total;
    int read_total;
    //历史记录
    QString sendbak;
    //串口状态
    bool serial_states;
    //时间定时器
    QTimer *timer;
    //循环发送定时器
    QTimer *loop_timer;
    //时间
    QString formattedTime;
    //多文本按键
    QList <QPushButton*> buttons;
    QList <QLineEdit*>lineEdits;
    QList <QCheckBox *>checkBoxs;
    //多按键索引
    int ButtonIndex;
};
#endif // WIDGET_H
