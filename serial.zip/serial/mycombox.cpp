#include "mycombox.h"

#include <QMouseEvent>


Mycombox::Mycombox(QWidget *parent)
{

}

void Mycombox::mousePressEvent(QMouseEvent *e)
{
    emit refresh();
    if(e->button()==Qt::LeftButton)
        emit refresh();
    QComboBox::mousePressEvent(e);
}
